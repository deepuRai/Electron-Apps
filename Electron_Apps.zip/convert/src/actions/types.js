export const ADD_VIDEO = 'add_video';
export const REMOVE_VIDEO = 'remove_video';
export const REMOVE_ALL_VIDEOS = 'remove_all_videos';
export const ADD_VIDEOS = 'add_videos';
export const VIDEO_PROGRESS = 'video_progress';
export const VIDEO_COMPLETE = 'video_complete';
