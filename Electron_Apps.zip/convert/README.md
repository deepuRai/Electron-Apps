### Getting started

`npm install`

Start dev server:

`npm start`

In a new terminal window:

`npm run electron`
